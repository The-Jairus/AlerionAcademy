# Alerion Academy — plataforma de capacitación

> La interfaz, los correos y los certificados están en inglés. Esta guía técnica
> está en español para el equipo que administra el servidor.

Aplicación web completa (frontend + backend + base de datos) para asignar capacitaciones,
controlar que la gente vea el contenido, evaluarla y emitir el certificado por correo.

Hecha con Flask y SQLite: no necesita servidor de base de datos ni servicios externos.

---

## 1. Instalación

```bash
cd plataforma_capacitacion
python3 -m venv .venv && source .venv/bin/activate      # en Windows: .venv\Scripts\activate
pip install -r requirements.txt
python seed.py            # datos de demostración (opcional pero recomendado la primera vez)
python app.py
```

Abre <http://127.0.0.1:5000>.

Requisitos del sistema:

| Herramienta | Para qué | Obligatoria |
|---|---|---|
| Python 3.10+ | la aplicación | sí |
| LibreOffice (`soffice`) | convertir `.pptx` a PDF al subir el curso | solo si subes presentaciones |
| ffmpeg / ffprobe | medir la duración de los videos | solo si subes videos |

Si no instalas LibreOffice puedes subir el material ya convertido a PDF.

### Usuarios de la demostración

| Rol | Usuario | Contraseña |
|---|---|---|
| Administrador | admin@flyalerion.com | Admin123* |
| Empleado | james@flyalerion.com | Course123* |
| Empleado | diana@flyalerion.com | Course123* |
| Empleado | marcus@flyalerion.com | Course123* |

`python seed.py --reiniciar` borra todo y vuelve a generar la demo.

### Empezar de cero con los cursos

Si la parte de cursos quedó inconsistente por una migración, `reiniciar.py` la reconstruye:

```bash
python reiniciar.py --cursos    # borra cursos, módulos, exámenes, asignaciones,
                                # intentos, certificados y el material subido.
                                # CONSERVA usuarios y configuración.
python reiniciar.py --todo      # borra además usuarios: queda como recién instalada.
```

En el servidor: `docker compose exec app python reiniciar.py --cursos`.
Las tablas no se vacían, se eliminan y se recrean desde el esquema actual, así que
no queda ningún resto de versiones anteriores. Al final revisa la integridad y lo informa.
Para arrancar con la base vacía: borra la carpeta `data/` y ejecuta `python app.py`; luego crea
el primer administrador con `python crear_admin.py`.

---

## 2. Cómo funciona

### Ingreso
Usuario y contraseña contra la tabla `usuarios`. Las contraseñas se guardan con hash PBKDF2-SHA256
(nunca en texto plano). Hay bloqueo temporal tras 8 intentos fallidos y protección CSRF en todos
los formularios.

### Vista de estudiante
1. **Mis cursos** lista solo lo asignado a ese usuario, con su avance y fecha límite.
2. **Contenido.** Si es video, se reproduce sin permitir adelantar: al saltar, la barra vuelve al
   punto ya alcanzado. Si es documento, el PDF o PPTX se muestra **página por página como imagen**,
   con un tiempo mínimo de lectura por página.
3. **Examen bloqueado.** El botón solo se habilita cuando el material está completo (95 % del video
   o la última página del documento). El bloqueo también se valida en el servidor: entrar a la URL
   del examen a mano no funciona.
4. **Certificado.** Al aprobar se genera el PDF y se envía al correo del usuario **con copia al
   correo del administrador**. También queda disponible para descarga.

### Cursos y módulos
Un curso es un contenedor: se crea primero y luego se le agregan los módulos que haga falta. Cada
módulo tiene su propio material (video, PDF o PPTX) y su propio examen. El curso se aprueba, y el
certificado se emite, solo cuando **todos** los módulos están aprobados. La nota del certificado es
el promedio de la mejor nota de cada módulo.

### Exámenes con banco de preguntas
Cada examen guarda un banco de preguntas. En su configuración se define cuántas preguntas ve la
persona en cada intento (0 = todas) y si se mezclan. Con la mezcla activa, cada intento saca preguntas
distintas y en distinto orden, y las opciones también se barajan sin perder cuál es la correcta.

### Plantilla del certificado
En **Settings → Certificate design** se puede seguir usando el diseño incluido o subir la plantilla
aprobada por la empresa en Word, PowerPoint u ODF. La plataforma reemplaza los marcadores
(`{{NAME}}`, `{{COURSE}}`, `{{DATE}}`, `{{SCORE}}`, `{{CODE}}` y demás; `{{DATE}}` es la
fecha de ejecución del curso en formato mm/dd/yyyy) y la convierte a PDF con
LibreOffice. El botón **Download a sample** genera un certificado de prueba para revisar el resultado
antes de usarlo. Si la plantilla falla, el sistema vuelve solo al diseño incluido para no dejar a
nadie sin certificado.

### Importación de registros anteriores
**Import records** carga capacitaciones hechas antes de la plataforma. Se puede importar de a uno,
adjuntando el PDF del certificado original, o en bloque con un CSV (`email,course,date,score,code`).
Los registros importados cuentan en el training summary igual que los ejecutados en la plataforma.

### Identidad visual
Los archivos de marca están en `static/img/`: `logo.png` (barra lateral y pantalla de ingreso),
`mark.png` (marca de agua), `certificate_logo.png` y `certificate_mark.png` (certificado) y
`favicon.png`. Los colores viven en el bloque de variables al inicio de `static/css/app.css` y se
repiten como `NAVY` y `GOLD` en `certificados.py`.

### Vista de administrador
- **Panel**: indicadores, sus propios cursos pendientes, vencidos y últimos certificados.
- **Usuarios**: crear, editar, cambiar contraseña, activar/desactivar y eliminar.
- **Cursos**: crear subiendo el material (video, PDF, PPTX, ODP), editar, ocultar y eliminar.
- **Asignar cursos**: varios cursos a varias personas de una vez, con fecha límite y aviso por correo.
- **Exámenes**: crear el examen de cada curso, definir puntaje mínimo e intentos, y cargar preguntas
  de selección única.
- **Resumen de capacitaciones**: todo lo asignado con filtros; lo pendiente aparece en rojo pastel
  y lo aprobado en blanco.
- **Certificados**: buscador por persona (nombre, correo o documento) y por curso, con descarga del
  PDF y reenvío por correo.
- **Configuración**: datos que salen en el certificado y servidor SMTP.

---

## 3. Correo

En **Configuración** defines el correo del administrador y el servidor SMTP.

- Con SMTP configurado, los certificados salen por ahí (STARTTLS en 587, SSL en 465).
- Sin SMTP, cada mensaje se guarda como archivo `.eml` en `data/correos_salida/` para que puedas
  abrirlo o reenviarlo. Así puedes probar todo el flujo sin servidor de correo.

Todos los envíos, con su resultado, quedan listados al final de la página de configuración.
El botón **Enviar prueba** verifica la configuración antes de depender de ella.

Ejemplo con Microsoft 365: servidor `smtp.office365.com`, puerto `587`, STARTTLS activo, usuario y
contraseña de una cuenta con permiso de envío. Con Gmail hay que usar una contraseña de aplicación.

---

## 4. Estructura

```
app.py              arranque, CSRF, filtros y manejo de errores
auth.py             ingreso, sesión, roles
estudiante.py       cursos asignados, visor, control de avance, examen, certificado
administrador.py    usuarios, cursos, asignaciones, exámenes, reportes, configuración
media.py            procesa el material: pptx→pdf→imágenes, duración de video
certificados.py     genera el PDF del certificado
mailer.py           envío SMTP o bandeja local
database.py         esquema SQLite y utilidades
seed.py             datos de demostración
templates/          páginas HTML
static/             CSS y JavaScript del visor
data/               base de datos, material, certificados y correos (se crea sola)
```

Tablas: `usuarios`, `cursos`, `asignaciones`, `quices`, `preguntas`, `opciones`, `intentos`,
`certificados`, `configuracion`, `correos`.

Estados de una asignación: `pendiente` → `en_progreso` → `aprobado` o `reprobado`.

---

## 5. Puesta en producción

Para publicarla en tu dominio (`https://capacitacion.tuempresa.com`) sigue
**[despliegue/GUIA_DESPLIEGUE.md](despliegue/GUIA_DESPLIEGUE.md)**. Trae tres caminos: un servicio
que la ejecuta por ti, un servidor propio con Docker y HTTPS automático, o un servidor propio con
Nginx instalado por script. Los archivos ya vienen listos: `Dockerfile`, `docker-compose.yml`,
`render.yaml` y la carpeta `despliegue/`.

`python app.py` levanta el servidor de desarrollo de Flask, suficiente para probar en tu
computador. Para uso real siempre va detrás de gunicorn y de Nginx o Caddy, como indica la guía.
Tres cosas por hacer antes de exponerlo:

1. **HTTPS obligatorio.** Con TLS activo, define la variable de entorno `HTTPS=1` para que la
   cookie de sesión solo viaje cifrada.
2. **Llave de sesión.** Se genera sola en `data/secret.key`; si prefieres, define la variable de
   entorno `SECRET_KEY`.
3. **Respaldos.** Copia la carpeta `data/` completa: ahí están la base, el material y los
   certificados emitidos.

Ajustes de reglas en `config.py`: `PORCENTAJE_MIN_VIDEO`, `SEGUNDOS_MIN_POR_PAGINA`,
`SALTO_MAX_SEGUNDOS` y el tamaño máximo de archivo.

### Capacidad y rendimiento

El material pesado (video) lo entrega **Caddy**, no la aplicación. Antes de servir un archivo,
Caddy consulta `/api/authorize`, donde la aplicación confirma en milisegundos si esa persona tiene
el curso asignado. Así el número de personas viendo video a la vez depende del ancho de banda y no
de los procesos de la aplicación.

- `MEDIA_DIRECT=1` activa ese reparto (ya viene puesto en `docker-compose.yml`).
- Sin esa variable, la aplicación sirve el video como antes: útil al desarrollar en local.
- `WORKERS` y `THREADS` en `.env` ajustan la concurrencia. Con 2 GB de RAM, 4 × 4 va cómodo;
  con 4 GB puedes subir a 6 × 4.

Referencias de tamaño: un documento de 30 páginas ocupa unos 15 MB ya convertido a imágenes, y un
video de 10 minutos en 720p unos 100 MB. En 50 GB caben del orden de 400 videos de esa duración.
La base de datos es despreciable: 1 KB por usuario.

### Optimización del almacenamiento

El disco es lo que marca el precio del servidor, así que todo lo que entra se comprime:

| | Antes | Ahora |
|---|---|---|
| Página de documento | ~63 KB (PNG) | ~15 KB (WebP) |
| Video subido | tal cual | recomprimido a 720p H.264 |
| Archivo fuente (PDF/PPTX) | se guardaba | se borra tras renderizar |

En material real esto libera alrededor de la mitad del espacio. Los parámetros están al
inicio de `media.py`: `RESOLUCION_VIDEO`, `CRF_VIDEO`, `ESCALA_PAGINA` y `CALIDAD_WEBP`.
Subir `CRF_VIDEO` a 30 o bajar `ESCALA_PAGINA` a 1.4 reduce más, con algo menos de nitidez.

Para el material que ya estaba subido:

```bash
docker compose exec app python optimizar.py --revisar    # cuánto se ahorraría
docker compose exec app python optimizar.py --aplicar    # aplicarlo
```

Ese script también borra las carpetas de material que quedaron sin curso asociado.

### Despliegue automático desde GitHub

`.github/workflows/deploy.yml` actualiza el servidor en cada push a `main`: respalda,
hace `git reset --hard`, reconstruye y comprueba que la aplicación responda. En GitHub,
**Settings → Secrets and variables → Actions**, define `SSH_HOST`, `SSH_USER`, `SSH_KEY`
(clave privada) y `APP_PATH`. En el servidor:

```bash
ssh-keygen -t ed25519 -C "github-deploy" -f ~/.ssh/github_deploy -N ""
cat ~/.ssh/github_deploy.pub >> ~/.ssh/authorized_keys
cat ~/.ssh/github_deploy      # el contenido va en el secreto SSH_KEY
```

### Respaldos

`despliegue/respaldo.sh` copia base, material y certificados, y conserva los últimos 14 días:

```bash
chmod +x despliegue/respaldo.sh
(crontab -l 2>/dev/null; echo "15 3 * * * /root/AlerionAcademy/plataforma_capacitacion/despliegue/respaldo.sh") | crontab -
```

### Sobre la protección del material
Las presentaciones y PDF se entregan como imágenes página por página, así que no se pueden editar
ni descargar el archivo original desde el visor. El video se sirve en streaming con el menú de
descarga desactivado. Ninguna plataforma web puede impedir del todo que alguien grabe la pantalla:
para material altamente confidencial se necesita DRM, que no está incluido aquí.


---

## 6. Identidad visual

Todos los colores corporativos están en un solo bloque, al inicio de
`static/css/app.css`:

```css
--brand-ink:  #0e1a28;   /* azul marino: barra lateral, títulos, certificado */
--brand-gold: #c6a15b;   /* dorado: estado activo, sellos, botones destacados */
```

Cambia esos valores y toda la plataforma se actualiza. Los mismos dos colores están
declarados como `NAVY` y `GOLD` al inicio de `certificados.py`, para que el PDF quede igual.

### Logos

| Archivo | Dónde aparece | Recomendación |
|---|---|---|
| `static/img/logo.png` | barra lateral y pantalla de ingreso | PNG con fondo transparente, versión clara, alto ≥ 60 px |
| `static/img/certificate_logo.png` | encabezado del certificado PDF | PNG con fondo transparente, versión oscura, alto ≥ 300 px |
| `static/img/favicon.png` | pestaña del navegador | PNG cuadrado de 64×64 px |

Si un archivo no existe, la plataforma no se rompe: muestra el nombre en texto.
Para subirlos al servidor basta con dejarlos en esas rutas y reconstruir con
`docker compose up -d --build`.

El nombre que aparece en la barra lateral, en los certificados y en los correos se
edita desde **Settings**, sin tocar el código.
